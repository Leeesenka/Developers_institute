const {db} = require('../config/db.js')

const getAllProducts = () => {
    return db('products')
    .select('id', 'name', 'price')
    .orderBy('name')
}

const getProduct = (product_id)=> {
    return db('products')
    .select('id', 'name', 'price')
    .where({id:product_id})
}


module.exports = {
    getAllProducts,
    getProduct
}